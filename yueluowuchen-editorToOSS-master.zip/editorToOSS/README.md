npm install/yarn/cnpm i 随你喜欢

npm run serve 启动
