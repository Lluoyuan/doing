import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// 引入UI框架
import iView from 'iview'
import 'iview/dist/styles/iview.css'
Vue.use(iView)

// 引入
import '@s'

Vue.config.productionTip = false

new Vue({
	router,
	store,
	render: h => h(App),
}).$mount('#app')
