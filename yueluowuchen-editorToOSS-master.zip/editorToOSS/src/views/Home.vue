<template>
    <div class="home">
        <c-Editor :catchData="catchData" />
    </div>
</template>

<script>
import Editor from '@c/editor'
export default {
	name: 'home',
	data() {
		return {
			inputContent: '',
			uploadURL: 'http:com.jiaozheng.oss/rap/images/editors/good',
			content: '',
		}
	},

	components: {
		'c-Editor': Editor,
	},

	computed: {},

	methods: {
		catchData(value) {
			this.content = value //在这里接受子组件传过来的参数，赋值给data里的参数
		},
	},

	mounted() {},
}
</script>